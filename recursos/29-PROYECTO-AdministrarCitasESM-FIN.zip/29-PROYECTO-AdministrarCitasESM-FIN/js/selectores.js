// Selectores
export const pacienteInput = document.querySelector('#paciente')
export const propietarioInput = document.querySelector('#propietario')
export const emailInput = document.querySelector('#email')
export const fechaInput = document.querySelector('#fecha')
export const sintomasInput = document.querySelector('#sintomas')

export const formulario = document.querySelector('#formulario-cita')
export const formularioInput = document.querySelector('#formulario-cita input[type="submit"]')
export const contenedorCitas = document.querySelector('#citas')
